import logo from './logo.svg';
import './App.css';
import HomePage from './Components/HomePage/HomePage';

function App() {
  return (
    <>
        <HomePage/>
    </>
  );
}

export default App;
