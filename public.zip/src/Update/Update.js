import React from 'react';
import "./Update.css"
import updateIMG from "./../assets/football-website-image/Group9144.png"
const Update = () => {
    return (
        <div>
            <img className="img-fluid update-img" src={updateIMG} alt="" />
        </div>
    );
};

export default Update;